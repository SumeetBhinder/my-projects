//
// Your comments here...
//

#ifndef FIRSTSTRUCT_TICKET_H
#define FIRSTSTRUCT_TICKET_H

#include <string>

/**
 * @struct Ticket
 * @brief A simple struct to hold data for a single theater ticket.
 *
 * This struct will use all public members for direct access.
 */
struct Ticket {
    // TODO: Add the data members for the Ticket struct here.
    //
    // Based on Part 2a of the lab instructions, you should add:
    // - a std::string for the section
    // - an int for the row
    // - an int for the seat
    // - a double for the price
};

#endif //FIRSTSTRUCT_TICKET_H