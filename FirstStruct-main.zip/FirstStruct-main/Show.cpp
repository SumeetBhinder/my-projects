//
// YOur comments here...
//

#include "Show.h"

// TODO: Implement the 6 methods (3 getters, 3 setters) for the Show struct.
//
// Remember to use the scope resolution operator (Show::) for each method.
//
// --- Accessors (Getters) ---
// (e.g., std::string Show::getTitle() { ... })
//
//
// --- Mutators (Setters) ---
// (e.g., void Show::setTitle(std::string newTitle) { ... })
//